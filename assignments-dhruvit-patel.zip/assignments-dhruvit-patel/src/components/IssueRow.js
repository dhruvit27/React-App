const IssueRow = (props) => {
  const rowStyle = props.rowStyle;
  const issue = props.issue;
  const dateOfJoining = issue.DateOfJoining ? issue.DateOfJoining.toDateString() : "Date not defined";

  if (props.issue === undefined) return <h3>IssueRow</h3>;
  return (
    <tr>
      {Object.entries(issue).map((value, index) => {
        if (value[0] === "DateOfJoining") {
            return (
                <td key={value} style={rowStyle}>
                    {dateOfJoining}
                </td>
            );
        }
        return (
          <td key={value} style={rowStyle}>
            {value[1]}
          </td>
        );
      })}
    </tr>
  );
};

export default IssueRow;
